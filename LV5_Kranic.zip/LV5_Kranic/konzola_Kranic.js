
$.fn.jquery


console.log($("h1").text());


$("p").text("Novi tekst odlomka");


$("p").css("background-color", "yellow");


$("img").attr("src", "slika.jpg");