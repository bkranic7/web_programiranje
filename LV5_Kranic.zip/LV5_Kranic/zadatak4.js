
$("#zelena").click(function () {
    $("ul").first().addClass("zelena");
});


$(".slike img").on("mouseenter", function () {
    $(this).addClass("crni-obrub");
});

$(".slike img").on("mouseleave", function () {
    $(this).removeClass("crni-obrub");
});

$(".slike img").on("click", function () {
    $(this).hide();
});


let sakriveno = false;

$("#abrakadabra").click(function () {
    $(".slike img").stop(true, true);

    if (!sakriveno) {
        $(".slike img").eq(0).fadeOut("fast");
        $(".slike img").eq(1).fadeOut("slow");
        $(".slike img").eq(2).fadeOut(5000);
        sakriveno = true;
    } else {
        $(".slike img").show();
        sakriveno = false;
    }
});