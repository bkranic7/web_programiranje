let smjesteno = 0;


$(".kvadrat").draggable({
    revert: "invalid"
});


function spusteno(spremnik, kvadrat, boja) {
    spremnik.css("background-color", boja);
    spremnik.css("color", "white");
    kvadrat.draggable("disable");
    smjesteno++;

    if (smjesteno === 2) {
        $("#poruka").text("Bravo!");
    }
}


$("#spremnik-crno").droppable({
    accept: "#crni",
    classes: { "ui-droppable-hover": "aktivan" },
    drop: function (event, ui) {
        spusteno($(this), ui.draggable, "black");
    }
});

$("#spremnik-crveno").droppable({
    accept: "#crveni",
    classes: { "ui-droppable-hover": "aktivan" },
    drop: function (event, ui) {
        spusteno($(this), ui.draggable, "red");
    }
});