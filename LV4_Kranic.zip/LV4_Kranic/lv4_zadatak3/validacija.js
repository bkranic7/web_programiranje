const kolegiji = [
    'Web programiranje',
    'Baze podataka',
    'Programiranje u Javi',
    'Matematika 2',
    'Računalne mreže',
    'Operacijski sustavi',
    'Diskretna matematika',
    'Programiranje 2'
];

const ECTS = 5;
const rezultat = document.getElementById('rezultat');
const popis = document.getElementById('popis');

function poruka() {
    
}


function procitajImePrezime() {
    const imePrezime = document.getElementById('ime').value.trim();
    const dijelovi = imePrezime.split(' ');

    if (dijelovi.length < 2 || dijelovi[0] === '' || dijelovi[1] === '') {
        return null;
    }

    return {
        ime: dijelovi[0],
        prezime: dijelovi.slice(1).join(' ')
    };
}

function procitajBroj() {
    const broj = Number(document.getElementById('brojKolegija').value);

    if (broj < 1 || broj > 8 || !Number.isInteger(broj)) {
        return null;
    }

    return broj;
}


function provjeriEmail(email) {
    if (email.trim() === '') {
        return 'E-mail adresa je obavezna.';
    }

    const brojAt = (email.match(/@/g) || []).length;

    if (brojAt !== 1) {
        return 'E-mail adresa smije sadržavati samo jedan znak @.';
    }

    const dijelovi = email.split('@');

    if (dijelovi[0].length < 2) {
        return 'Prije znaka @ moraju biti barem 2 znaka.';
    }

    if (dijelovi[1].length < 2) {
        return 'Nakon znaka @ moraju biti barem 2 znaka.';
    }

    if (!dijelovi[1].includes('.')) {
        return 'Nakon znaka @ mora postojati točka.';
    }

    const zadnjaTocka = email.lastIndexOf('.');

    if (email.length - zadnjaTocka - 1 < 2) {
        return 'Nakon zadnje točke moraju biti barem 2 znaka.';
    }

    return '';
}




document.getElementById('pozdrav').addEventListener('dblclick', function() {
    const osoba = procitajImePrezime();

    if (osoba === null) {
        alert('Unesite ime i prezime!');
    } else {
        alert('Dobro došli, ' + osoba.ime + ' ' + osoba.prezime + '!');
    }
});



document.getElementById('pomoc').addEventListener('mouseover', function() {
    rezultat.textContent = 'Broj kolegija mora biti između 1 i 8.';
});

document.getElementById('pomoc').addEventListener('mouseout', function() {
    rezultat.textContent = '';
});



document.getElementById('kolegiji').addEventListener('mouseup', function() {
    const broj = procitajBroj();

    if (broj === null) {
        rezultat.textContent = 'Broj kolegija mora biti između 1 i 8.';
        popis.value = '';
        return;
    }

    popis.value = '';

    for (let i = 0; i < broj; i++) {
        popis.value += 'Kolegij ' + (i + 1) + ': ' + kolegiji[i] + '\n';
    }

    rezultat.textContent = 'Ukupno ECTS bodova: ' + (broj * ECTS);
});



document.getElementById('obrisi').addEventListener('click', function() {
    if (confirm('Jeste li sigurni da želite obrisati kolegije?')) {
        popis.value = '';
        rezultat.textContent = '';
    }
});




document.getElementById('prijavi').addEventListener('click', function() {


    const osoba = procitajImePrezime();

    if (osoba === null) {
        alert('Unesite ime i prezime!');
        return;
    }


    const email = document.getElementById('email').value;
    const greskaEmail = provjeriEmail(email);

    if (greskaEmail !== '') {
        alert(greskaEmail);
        return;
    }


    const broj = procitajBroj();

    if (broj === null) {
        alert('Broj kolegija mora biti cijeli broj između 1 i 8.');
        return;
    }


    if (popis.value.trim() === '') {
        alert('Niste odabrali kolegije! Kliknite na gumb Kolegiji.');
        return;
    }

    alert('Uspješna prijava, ' + osoba.ime + ' ' + osoba.prezime + '!');
});




document.getElementById('pozdrav')

document.getElementById('pomoc')
document.getElementById('pomoc')

document.getElementById('kolegiji')

document.getElementById('obrisi')

document.getElementById('prijavi')
