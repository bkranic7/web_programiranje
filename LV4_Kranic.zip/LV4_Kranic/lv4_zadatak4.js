
class Macka {
    constructor(ime, boja, dob, spol) {
        this.ime = ime;
        this.boja = boja;
        this.dob = dob;
        this.spol = spol;
    }

     opis() {
        return "Ime: " + this.ime
            + ", boja: " + this.boja
            + ", dob: " + this.dob
            + ", spol: " + this.spol;
    }

    promijeniDob(novaDob) {
        this.dob = novaDob;
    }
}

const tigar = new Macka("Tigar", "narančasta", 3, "muški");
const micika = new Macka("Micika", "bijela", 2, "ženski");


document.getElementById("macke").innerHTML = tigar.opis();

micika.promijeniDob(7);

const ispisDob = document.getElementById("macke");
ispisDob.innerHTML = tigar.opis();
ispisDob.innerHTML +=
"<br>Nova dob micike je: " + micika.dob + " godina.";


document.getElementById("izmjena").innerHTML = 
"Dokument je poslijednji put izmjenjen: " + document.lastModified;